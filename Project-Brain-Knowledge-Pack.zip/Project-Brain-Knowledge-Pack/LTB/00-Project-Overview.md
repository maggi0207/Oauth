# LTB – Project Overview

**Project:** Last Time Buy (LTB) capability.  
**Related application:** The supplied analysis describes LTB and Scrap capabilities within the planning/Scrap Agent codebase. Confirm the exact current repository and deployment name.

## Purpose

Support LTB-related product eligibility, details, planner adjustments and procurement approval workflows through registered application capabilities and MCP tools.

## Known LTB tools reported in the supplied repository analysis

| Tool | Reported purpose |
|---|---|
| `eligible_ltb_items` | Retrieve eligible LTB items/catalogue |
| `get_local_ltb_details` | Retrieve procurement-location details |
| `update_planner_adjustments` | Update planner adjustment values |
| `ltb-procurement-approval` | Approve or reject LTB quantities |

These names are taken from prior repository analysis shared in this conversation. Verify tool schemas, permissions and environment availability in the current source and live MCP server before execution.

## Important domain terms

- LTB / Last Time Buy.
- Last Buy / Time Buy (verify word-boundary matching).
- End of Sale.
- FGI / DGI.
- Repair Yield / Return Yield.
- Procurement Location.
- PID, Product Family, BU and PLC are filters/grains, not LTB domain signals by themselves.

## Architecture goals

- Keep LTB execution restricted to registered LTB capabilities.
- Use deterministic routing and validated parameters.
- Preserve trusted authenticated user identity for sensitive actions.
- Do not allow model-generated SQL or unregistered execution identifiers.
- Keep Scrap execution disabled in an LTB-only production deployment if that is the approved release scope.

## Related documents

- `01-LTB-Capability-and-Tool-Catalog.md`
- `02-Context-Aware-Routing-Design.md`
- `03-Persistent-Memory-Target-Architecture.md`
- `04-Scrap-Execution-Feature-Control.md`
- `05-Test-Plan-and-Acceptance.md`
- `06-Development-and-Deployment-Runbook-Template.md`
