# LTB – Context-Aware Routing Design

**Status:** Proposed target design, informed by the supplied routing analysis. Do not treat as implemented until verified in the current repository.

## Problem

A domain-neutral follow-up can be misrouted when each component classifies the latest sentence independently. For example:

1. User: “Show me all eligible LTB products.”
2. User: “Can you show recommendation for product 8818-FC0=?”

The second message does not say LTB. A product ID is an entity, not a domain. It must not silently switch to Scrap.

## Target principle

Build one deterministic routing decision from the current user message and previous user-authored messages. Pass the same decision to the classifier, dispatcher and both capability handlers.

Assistant-generated text must not establish or overwrite the user's last explicit domain.

## Routing precedence

| Priority | Current-turn signal | Route this turn | Remembered explicit domain |
|---|---|---|---|
| 1 | Current message explicitly says LTB only | LTB | LTB |
| 2 | Current message explicitly says Scrap only | Scrap | Scrap |
| 3 | Both domains are mentioned ambiguously | Clarify, unless a verified stronger signal resolves it | Preserve previous explicit domain |
| 4 | Product plus verified depot/location signal, with no explicit domain | Scrap for this request | Preserve previous explicit domain |
| 5 | Domain-neutral recommendation/details/product follow-up | Previous explicit domain | Unchanged |
| 6 | No explicit domain, no strong signal and no history | Clarify | None |

The conflict behaviour must be validated with business owners before treating it as final. In particular, a product-plus-depot signal is a current-turn Scrap signal only where the existing application rules confirm that interpretation.

## State distinction

- `selected_domain`: capability for the current request.
- `last_explicit_domain`: most recent domain explicitly written by the user and inherited by future neutral follow-ups.

These may differ on a product-plus-depot turn.

## Required examples

### LTB follow-up

`Show me all eligible LTB products.` → `Can you show recommendation for product 8818-FC0=?`

Expected: LTB.

### Scrap follow-up

`Show scrap inventory.` → `Can you show recommendation for product 8818-FC0=?`

Expected: Scrap.

### Strong Scrap signal during LTB discussion

`Show eligible LTB products.` → `Show recommendation for 8818-FC0= at U98.`

Expected: route current request to Scrap; retain last explicitly selected domain as LTB.

### Explicit switch

`Show scrap inventory.` → `Show LTB recommendation.`

Expected: LTB; remembered explicit domain becomes LTB.

### New conversation

`Recommend product 8818-FC0=`

Expected: clarify unless another independently verified domain signal exists.

## Implementation guidance

- Central Context Builder creates the context and routing decision once per turn.
- Central routing result is passed to all downstream nodes.
- LTB and Scrap handlers validate the selected domain but do not independently reroute.
- Scrap keyword tool selection occurs only after Scrap has been selected.
- If routing is unresolved, no business tool is called.
