# LTB Production – Scrap Execution Feature Control

**Status:** Proposed release control based on the project discussion. Verify the current code and release scope with the LTB/Scrap owners.

## Objective

LTB is intended to be deployed to production independently while Scrap execution remains disabled until it is approved for release.

Use one boolean configuration flag:

```yaml
features:
  scrap_enabled: false
```

Do not introduce an unnecessary feature-flag platform or an `ltb_enabled` flag for this requirement.

## Required enforcement

When `scrap_enabled=false`:

1. Do not register Scrap capability for execution.
2. Do not expose Scrap MCP tool definitions to the LTB LLM.
3. Reject Scrap capability dispatch before a handler or MCP tool is invoked.
4. Ensure streaming and direct invocation paths enforce the same rule.
5. Return a clear disabled/unsupported response for explicit Scrap requests.
6. Do not silently redirect Scrap requests to LTB.
7. Keep LTB execution unaffected.

When `scrap_enabled=true`, existing Scrap capability behaviour may be enabled through configuration, subject to tests and release approval.

## Additional production hardening

A code-level flag controls application behaviour. For a stronger isolation boundary, the LTB production deployment should also omit Scrap MCP credentials and, where feasible, restrict network access to Scrap services.

## Mandatory tests

- `scrap_enabled=false` + LTB request → LTB executes.
- `scrap_enabled=false` + explicit Scrap request → disabled response.
- LLM mistakenly selects Scrap → execution blocked.
- Scrap tool selected internally → tool invocation blocked.
- Direct API and streaming API → both blocked.
- Scrap MCP invocation count remains zero while disabled.
- `scrap_enabled=true` → existing Scrap tests pass.

## Release checklist

- Confirm flag value in the production deployment configuration.
- Confirm Scrap tools are not registered/exposed.
- Confirm Scrap credentials are absent where possible.
- Confirm zero Scrap tool calls in production-config test.
- Record approval and rollback procedure.
