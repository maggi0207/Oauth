# LTB – Persistent Conversation Memory Target Architecture

**Status:** Proposed target design. The actual runtime's Kubernetes-provided PostgreSQL integration must be inspected and reused. This document does not request a new PostgreSQL server or separate database service.

## Objective

Allow a user to close and reopen an LTB conversation and continue the workflow after runtime restarts or when a request reaches another runtime replica.

## Target flow

```mermaid
flowchart TD
    UI[Chat UI] --> API[Authenticated LTB API]
    API --> OWN[Validate user/thread ownership]
    OWN --> CP[LangGraph Checkpointer integration]
    CP <--> PG[(Runtime-provided PostgreSQL)]
    CP --> RESTORE[Restore graph state using stable thread ID]
    RESTORE --> CB[Build fresh Context Package]
    CB --> LLM[LTB planning/classification]
    LLM --> EXEC[Validate registered LTB execution]
    EXEC --> TOOLS[Approved LTB MCP tools]
    TOOLS --> UPDATE[Update graph state]
    UPDATE --> CP
```

## Responsibilities

- **Thread ID:** identifies one conversation; keep stable across turns.
- **Checkpointer:** persists and restores LangGraph state for that thread.
- **PostgreSQL:** durable storage already provided by the runtime/platform, subject to configuration verification.
- **Context Builder:** rebuilds request-specific context from restored state and the current question.
- **Context window management:** selects a bounded subset of history and workflow state for the LLM.

## State to retain

- Conversation message state, using the existing message reducer correctly.
- Last selected LTB procedure.
- Relevant PID and validated filters (Product Family, BU, PLC where applicable).
- Compact workflow parameters and status.
- Relevant execution summary/reference, not large raw result payloads.
- State schema version.

## Do not persist as permanent state

- Entire Context Package on every request.
- Credentials, access tokens or secrets.
- Large raw MCP result sets when a compact reference or summary is sufficient.
- Unvalidated LLM guesses as authoritative business filters.

## Thread and security requirements

- One stable thread ID per conversation.
- New conversation gets a new thread ID.
- Same thread ID is used by streaming and non-streaming paths.
- Thread ownership must be checked against trusted authenticated principal.
- Different users and conversations must not share state.
- Multiple runtime replicas must use the same approved persistent backend.

## Runtime integration

Inspect the actual LTB runtime and SDI reference branch. If LTB uses a custom FastAPI graph runtime, integrate the supported asynchronous PostgreSQL checkpointer into the actual parent graph lifecycle. If the runtime/platform already manages checkpointing, use that supported integration instead of attaching a competing checkpointer.

Do not create or provision a new PostgreSQL server. Reuse the runtime's PostgreSQL integration.

## Mandatory validation

1. Start a conversation and ask for LTB details for PID ABC123.
2. Verify checkpoint save.
3. Restart the LTB runtime.
4. Reopen the same conversation with the same thread ID.
5. Ask for details for the same PID.
6. Verify the PID and workflow context are restored.
7. Repeat against another runtime replica.
8. Verify a new conversation receives clean state.
