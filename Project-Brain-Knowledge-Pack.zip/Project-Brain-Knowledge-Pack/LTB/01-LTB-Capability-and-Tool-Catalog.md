# LTB – Capability and Tool Catalog

**Evidence status:** Tool names and terminology below were reported in the supplied repository analysis. Confirm against current tool definitions and live MCP `list_tools` results.

## Known tool names

| Tool | Reported purpose | Operational caution |
|---|---|---|
| `eligible_ltb_items` | Retrieve eligible LTB item information | Read/query semantics must be checked in current schema |
| `get_local_ltb_details` | Retrieve local procurement-location information | Validate accepted location filters |
| `update_planner_adjustments` | Update planner adjustments | Write operation; require authenticated identity and authorization |
| `ltb-procurement-approval` | Approve or reject procurement quantities | Sensitive action; require explicit authorization/approval flow |

## Vocabulary

### Explicit LTB indicators reported in source

- `ltb`
- `last time buy`
- `last-time-buy`
- `lasttime buy`
- `last buy`
- `time buy`
- `end of sale`

### LTB-related business terms reported in source

- FGI
- DGI
- Repair Yield
- Return Yield
- Procurement Location

### Filter/grain terms – not domains by themselves

- PID
- Product Family / PF
- Business Unit / BU
- PLC

### Ambiguous terms

- recommendation
- eligible / eligibility
- details
- approve / reject
- forecast

Do not classify a request as LTB based solely on a product ID, PID, product family, BU or generic word such as “recommendation”. Use current explicit domain wording or verified conversation context.

## Live discovery checklist

Before adding or changing routing vocabulary:

1. Connect to the configured LTB MCP server using approved credentials.
2. Call read-only `list_tools` discovery.
3. Record tool names, descriptions and input schemas.
4. Compare with static registries and this document.
5. Mark each vocabulary item as live-verified or source-only.
6. Do not execute write operations as part of vocabulary discovery.
