# LTB – Test Plan and Acceptance Criteria

## 1. Routing regression tests

| Scenario | Expected route |
|---|---|
| Explicit LTB question | LTB |
| Explicit Scrap question | Scrap, if enabled |
| LTB followed by neutral product recommendation | LTB |
| Scrap followed by neutral product recommendation | Scrap |
| LTB followed by explicit Scrap | Scrap; update remembered explicit domain |
| Scrap followed by explicit LTB | LTB; update remembered explicit domain |
| LTB followed by product plus depot | Scrap for this turn; remember LTB |
| Product ID alone in a new thread | Clarify |
| Recommendation alone in a new thread | Clarify |
| Assistant mentions LTB/Scrap but user did not | Do not change remembered explicit domain |
| Separate thread | No memory leakage |

## 2. LTB tool tests

Verify current registered tools and schemas before testing:

- `eligible_ltb_items`
- `get_local_ltb_details`
- `update_planner_adjustments`
- `ltb-procurement-approval`

Test read operations and write/approval operations separately. Write and approval tools must continue to require their existing authorization and confirmation rules.

## 3. Persistence tests

1. Create a new thread.
2. Execute an LTB request for a known test PID.
3. Verify state is checkpointed.
4. Recreate the graph/runtime.
5. Resume with the same thread ID.
6. Ask a follow-up referring to the same PID.
7. Verify the PID and filters are restored.
8. Verify a new thread does not inherit state.
9. Verify user/thread ownership.
10. Verify another runtime replica can restore the thread if the deployment is multi-replica.

Use runtime-provided PostgreSQL for the durable integration test. In-memory tests are not proof of durable persistence.

## 4. LTB production isolation tests

With `scrap_enabled=false`:

- No Scrap handler execution.
- No Scrap MCP tool definitions exposed to the model.
- No Scrap MCP invocation.
- LTB remains operational.
- Explicit Scrap requests receive a clear disabled response.

## 5. Acceptance criteria

The implementation is accepted only when:

- Follow-ups retain the correct LTB/Scrap domain.
- One shared routing decision is consumed by classifier, dispatcher and handlers.
- Stable thread identity is preserved.
- Durable state survives runtime restart when configured.
- LTB product/filter context is restored.
- Users and threads remain isolated.
- LTB production can run with Scrap disabled and zero Scrap tool calls.
- Existing approved LTB business execution contracts remain intact.
