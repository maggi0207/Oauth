# LTB – Development and Deployment Runbook Template

**Important:** This is a template, not an approved company runbook. Fill it using the current repository's README/pipeline and the platform team's instructions. Do not invent commands, namespaces, registry names or URLs.

## Local development

- Repository URL: **[fill from source control]**
- Local repository path: **[fill]**
- Required Node/Python versions: **[fill from project config]**
- Dependency installation: **[fill from README/lockfiles]**
- Local start command: **[fill from README]**
- Required MCP servers: **[fill from actual config]**
- Required environment variables: **[names only; never put values here]**

## Test procedure

- Unit test command: **[fill]**
- Routing test command: **[fill]**
- Integration test command: **[fill]**
- Persistence test command: **[fill]**
- Expected test suite/count: **[fill from CI]**

## Kubernetes deployment

- Cluster/context: **[approved platform value]**
- Namespace: **[approved platform value]**
- Workload/deployment: **[actual workload name]**
- Container image repository: **[actual registry path]**
- Image tag convention: **[approved convention]**
- ConfigMap: **[actual reference]**
- Secrets: **[secret names only]**
- PostgreSQL runtime integration: **[document the existing platform-provided connection mechanism]**

## Release controls

- `scrap_enabled`: `false` for LTB-only production, if approved.
- Confirm no Scrap MCP tools are registered/exposed.
- Confirm no Scrap credentials are provided to the LTB runtime where feasible.
- Confirm LTB smoke tests.
- Confirm checkpoint save and restore if persistent memory is enabled.

## Rollback

- Previous image/tag: **[fill]**
- Rollback command/pipeline: **[approved process]**
- Database/checkpoint compatibility considerations: **[fill]**
- Post-rollback smoke tests: **[fill]**
