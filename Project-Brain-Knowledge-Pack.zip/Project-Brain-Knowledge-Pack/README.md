# Project Brain – Engineering Knowledge Pack

This pack is a starter knowledge base for indexing into Project Brain. It separates SDI and LTB material so project context does not get mixed.

## Folder structure

- `SDI/` – Strategic Demand Intelligence architecture, context management, skills, persistence assessment, and operating notes.
- `LTB/` – LTB capability, tools, routing design, persistence target, Scrap execution controls, and test plan.
- `Global/` – shared glossary and instructions for maintaining this knowledge base.

## Evidence labels

Documents use these labels:

- **Verified from supplied project analysis:** explicitly reported in the SDI or Scrap/LTB repository analysis shared in this conversation. Reconfirm against the current branch before implementation.
- **Proposed:** recommended target design, not a claim about existing code.
- **Needs repository verification:** exact paths, configuration, runtime behaviour, or deployment settings must be checked in the current checkout.
- **Needs platform confirmation:** depends on Kubernetes/runtime configuration or internal infrastructure.

## Important limitations

This is a generated starter pack based on information supplied in the project discussions. It is not a full export of private repositories, company Confluence pages, internal deployment runbooks, or live runtime configuration. It does not contain credentials, secrets, certificates, internal URLs, or unverified deployment commands.

Before treating any document as authoritative, compare it with the current source branch and approved company procedures. Replace templates with actual runbooks when those are available.

## Recommended Project Brain setup

1. Add SDI as a project and import only the `SDI/` folder.
2. Add LTB as a separate project and import only the `LTB/` folder.
3. Import `Global/` into the Global Office Knowledge area, if that feature is enabled.
4. Keep repository indexing separate from these documents; source code is better inspected directly from the selected repository.
5. Re-index after updating these documents.
