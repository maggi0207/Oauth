# SDI – Open Gaps and Decision Log

## Known gaps from the supplied source analysis

1. The inspected runtime graph has no LangGraph checkpointer.
2. Runtime workflow memory is process-local and expires/evicts entries.
3. Browser transcript persistence does not automatically restore runtime workflow state.
4. The inspected request flow sends the current user message, not the complete transcript.
5. User/thread ownership enforcement needs verification and strengthening.
6. Multi-pod restoration is not available through process-local dictionaries.
7. No durable conversation summarization was found in the inspected implementation.

## Decisions for future work

| ID | Decision | Status |
|---|---|---|
| SDI-DEC-001 | Rebuild Context Package each turn | Existing design principle; verify current code |
| SDI-DEC-002 | Keep transcript and graph checkpoint responsibilities separate | Recommended |
| SDI-DEC-003 | Use platform-approved persistence if adding durable state | Requires platform confirmation |
| SDI-DEC-004 | Bind each thread to authenticated principal | Required security control |
| SDI-DEC-005 | Do not send full history without bounded context selection | Recommended |

## Open questions

- Does the deployed LangGraph runtime/platform provide managed persistence outside the repository configuration?
- What approved persistence backend and retention policy are available?
- What is the authoritative server-side transcript API, if any?
- What are the approved production deployment and rollback steps?
- Which live skills, tools and execution IDs are enabled in each environment?

## Change log

- Generated starter document on 2026-11-09 from supplied project discussions and analysis.
- Revalidate against current SDI source and deployment before treating as authoritative.
