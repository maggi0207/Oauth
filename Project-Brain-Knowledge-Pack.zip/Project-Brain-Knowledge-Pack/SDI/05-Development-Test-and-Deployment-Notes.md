# SDI – Development, Testing and Deployment Notes

**Status:** Starter engineering reference. This is not an approved company deployment runbook. Add exact commands, environment names and approvals only from current repository documentation or the platform team.

## Local health endpoints reported in prior project notes

| Component | Local endpoint | Purpose |
|---|---|---|
| Planning service | `http://127.0.0.1:8061/api/health` | Health |
| Planning service | `http://127.0.0.1:8061/api/ready` | Readiness |
| Runtime | `http://127.0.0.1:8082/health` | Health |
| Runtime | `http://127.0.0.1:8082/ready` | Readiness |

These were reported for a previous local development setup. Verify current ports and endpoint paths before use.

## Development checklist

1. Confirm the correct UI, service and runtime branches.
2. Check repository instructions and required Node/Python versions.
3. Configure environment variables using approved local secrets.
4. Start dependent services in the documented order.
5. Confirm health and readiness endpoints.
6. Run unit tests before starting the UI.
7. Run end-to-end tests with clearly identified mock or live dependencies.
8. Verify request correlation across UI, service and runtime logs.

## Testing checklist

- Routing and skill selection.
- Parameter and identifier validation.
- Forecast Outlook and Accuracy procedures.
- RMA and Install Base flows where enabled.
- Follow-up filters and same-entity references.
- Error handling and partial results.
- Streaming behaviour.
- Authentication and user isolation.
- Runtime restart and state-restoration behaviour if persistence is enabled.

## Deployment runbook template

Complete this from the official internal deployment process:

1. Branch and commit approval: **[fill from approved process]**
2. Build command: **[fill from repository pipeline]**
3. Image repository and tag: **[fill from deployment configuration]**
4. Kubernetes namespace/context: **[fill from platform team]**
5. ConfigMap/Secret references: **[fill from approved secret management]**
6. Deployment/Helm command: **[fill from approved pipeline]**
7. Health/readiness verification: **[fill from deployed endpoints]**
8. Smoke tests: **[fill from release checklist]**
9. Rollback procedure: **[fill from approved release process]**

Never substitute guessed commands for company-approved deployment steps.
