# SDI – System Architecture

**Evidence status:** The architecture summary below is based on the supplied SDI repository analysis. Verify all paths and endpoint contracts against the current branch before implementation.

## High-level request flow

```mermaid
flowchart TD
    U[Angular Chat UI] -->|current message + session/thread ID| S[Planning Service / BFF]
    S --> R[SDI Runtime API]
    R --> G[LangGraph chat_agent]
    G --> C[Context Builder]
    C --> P[Routing / Planning LLM calls]
    P --> O[SdiOrchestrator]
    O --> X[Validated skill execution]
    X --> M[MCP / approved data tools]
    M --> O
    O --> G
    G --> S
    S --> U
```

## Known source locations from the supplied analysis

| Area | Reported source location | Responsibility |
|---|---|---|
| UI session storage | `ssc-planning-sdi-ui/src/app/services/session-store.service.ts` | Creates and persists browser-side chat sessions |
| UI chat flow | `ssc-planning-sdi-ui/src/app/features/chat/chat-container.ts` | Sends messages and restores selected sessions |
| UI API client | `ssc-planning-sdi-ui/src/app/services/api.service.ts` | Calls planning service streaming endpoint |
| Service request mapping | `ssc-planning-sdi-ser/api/app.py` | Maps request and session information |
| Service runtime client | `ssc-planning-sdi-ser/api/runtime_client.py` | Builds runtime request and thread identifier |
| Runtime graph | `ssc-planning-sdi-rt/agents/chat_agent.py` | Defines graph state, chat node and graph compilation |
| Runtime orchestrator | `ssc-planning-sdi-rt/sdi_agent/orchestrator.py` | Coordinates interpretation and execution; contains temporary session state |
| Context builder | `ssc-planning-sdi-rt/sdi_agent/context/context_builder.py` | Assembles bounded context for LLM calls |

## Important request-path distinction

The supplied analysis reports that the UI keeps a stable session ID and sends it as the session/thread identifier. It also reports that the runtime's graph input contains only the current user message on the path inspected. Consequently, a visible transcript in the browser does not prove the runtime has restored that transcript or the old workflow state.

Verify both streaming and direct invocation paths. They must use the same canonical thread identifier and the same state-restoration mechanism if persistent graph state is introduced.

## Architecture rules

1. Do not infer durable memory from the existence of a thread ID.
2. Do not assume browser local storage is shared across devices or browsers.
3. Do not treat an LLM prompt supplement as durable storage.
4. Keep user identity sourced from trusted authentication context.
5. Validate skills, execution IDs, filters and parameters before tool execution.
6. Document current behaviour separately from proposed target architecture.
