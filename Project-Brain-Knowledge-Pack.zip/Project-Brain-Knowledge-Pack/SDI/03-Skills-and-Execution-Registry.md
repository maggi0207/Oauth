# SDI – Skills and Execution Registry

## Purpose

SDI uses skill definitions and registered execution procedures to constrain how planner questions are interpreted and executed.

The supplied project notes describe a flow in which a skill catalog helps identify a relevant skill, the runtime loads the matching skill definition, and a subsequent interpretation step identifies a procedure and parameters.

## Known capability areas

- Forecast.
- RMA.
- Install Base.

## Known execution identifiers reported in project notes

| Procedure | Execution ID | Verification needed |
|---|---|---|
| Forecast Outlook | `sdi.script.outlook` | Confirm current registry and builder |
| Forecast Accuracy | `sdi.script.accuracy` | Confirm current registry and builder |
| RMA | `sdi.script.rma` | Confirm current registry and builder |

## Execution safety rules

- The model must not generate arbitrary SQL.
- Only registered execution IDs are eligible for execution.
- Parameters and filters must be validated by application code.
- Planner identity must come from trusted application authentication context.
- High-confidentiality data requires appropriate authorization checks.
- Do not treat an LLM-generated plan as authorization to execute a write operation.

## Skill source and retrieval

The broader SDI design discussions describe loading skill definitions from the Data Request MCP catalog where configured, with local skill files as a possible fallback in some implementations. Confirm the current runtime's source of truth before changing skill loading.

## Open verification items

- Confirm current skill catalogue and its source.
- Confirm current procedure IDs.
- Confirm required parameter schemas and filter rules.
- Confirm which data tools are available in each environment.
- Confirm write-back approval requirements and audit behaviour.
