# SDI – Conversation Persistence Assessment

**Assessment basis:** Detailed source analysis supplied in the project discussion. This is not a live cluster verification.

## Executive finding

The inspected SDI implementation has stable UI session identifiers and browser-side transcript persistence, but no LangGraph checkpointer configured on the inspected production graph.

The supplied analysis reports that `agents/chat_agent.py` compiles the graph with `workflow.compile()` and that `tests/test_context.py` asserts `graph.checkpointer is None`.

## Three different storage layers

| Layer | Reported content | Durability |
|---|---|---|
| Browser `localStorage` | UI transcript, tables and activity under `sdi-agent-sessions-v1`; capped at 30 sessions | Survives closing/reopening in the same browser profile; not shared across devices |
| Runtime `_sessions` | Last skill/procedure, string filters and last plan | Process-local; reported 30-minute expiry and 1,024-session maximum; lost on process restart |
| LangGraph `AgentState` | Current invocation messages, response, context package and plan | Per-run state in the inspected path; no checkpoint restore/persist |

## Thread ID

The supplied analysis reports that the UI creates an `SDI-UI-` session ID and reuses it for follow-up turns. The planning service forwards session/thread ID to the runtime. The runtime derives a platform thread identifier and sets `configurable.thread_id` when a session ID exists.

**Important:** Passing `configurable.thread_id` without a configured checkpointer does not provide durable graph-state storage.

## Reopening scenario

The browser can restore the visible transcript from local storage. However, the runtime does not automatically receive the old transcript on every request, and the inspected graph does not restore old state from a checkpoint.

The supplied analysis reports that a follow-up referring to “same PID” may only resolve if the same process still holds its temporary session entry. After process restart or runtime-memory expiry, the runtime may no longer know the PID.

## Recommended target for a future persistence change

- Keep a stable thread ID per conversation.
- Use the runtime/platform-supported persistent checkpointer if one is available and approved.
- Persist only the graph state needed to resume workflows.
- Rebuild the Context Package per turn.
- Keep transcript storage and agent-state storage conceptually separate.
- Validate principal-to-thread ownership.
- Test after process/pod restart and across runtime replicas.

## Do not claim

Do not claim that SDI has durable LangGraph memory unless the current branch and deployed runtime demonstrate actual checkpoint writes and restore. Deployment platform behaviour may differ from the repository code and requires separate verification.
