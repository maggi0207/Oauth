# SDI – Project Overview

**Project:** Strategic Demand Intelligence (SDI)  
**Purpose:** Help planners ask questions about service demand, forecast outlook and accuracy, install base, RMA and related planning information.  
**Status:** Starter knowledge document; verify against the current repository and approved product requirements.

## Main components

The supplied project analysis identifies three principal application areas:

- **UI:** `ssc-planning-sdi-ui` – Angular chat experience and conversation list.
- **Planning service:** `ssc-planning-sdi-ser` – service/BFF layer that accepts chat requests and forwards them to the runtime.
- **Runtime:** `ssc-planning-sdi-rt` – FastAPI and LangGraph agent runtime.

Exact repository names and deployment boundaries must be rechecked in the current workspace.

## Known agent capabilities

The project discussions identify Forecast, RMA and Install Base as SDI capability areas. Known registered execution identifiers reported in the supplied architecture notes include:

| Capability / procedure | Execution identifier | Notes |
|---|---|---|
| Forecast Outlook | `sdi.script.outlook` | Existing registered execution reported in project notes |
| Forecast Accuracy | `sdi.script.accuracy` | Existing registered execution reported in project notes |
| RMA | `sdi.script.rma` | Existing registered execution reported in project notes |

Do not invent SQL, data-source mappings, model IDs or forecast selection rules. Inspect the relevant skill definitions and execution builders before changing behaviour.

## Architecture principles

- Keep the Angular UI, planning service and runtime responsibilities distinct.
- Keep business execution identifiers registered and validated in the runtime.
- The LLM may help interpret a question and propose a plan; execution must remain constrained by registered procedures and validated parameters.
- Treat authenticated planner identity as trusted application context, not model-generated information.
- Keep large datasets and raw query results out of prompts when compact references or summaries are sufficient.

## Related documents

- `01-System-Architecture.md`
- `02-Context-Builder-and-Conversation-Context.md`
- `03-Skills-and-Execution-Registry.md`
- `04-Conversation-Persistence-Assessment.md`
- `05-Development-Test-and-Deployment-Notes.md`
- `06-Open-Gaps-and-Decision-Log.md`
