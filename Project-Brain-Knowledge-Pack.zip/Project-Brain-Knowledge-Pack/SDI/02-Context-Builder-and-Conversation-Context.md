# SDI – Context Builder and Conversation Context

**Evidence status:** Based on the supplied analysis of the `docs/SPL-120823-persist-chat-context` branch and the subsequent persistence assessment. Recheck the exact current branch before relying on implementation details.

## Purpose

The SDI Context Builder assembles relevant information for each user turn so routing and planning calls do not have to infer everything from the latest sentence alone.

The supplied analysis reports that `ContextBuilder.build_context()` creates a `ContextPackage` with structured context such as:

- System instructions.
- Business context.
- Routing context from the routing lexicon.
- Knowledge context.
- Skill and tool context.
- Conversation context.
- User context.
- Workflow context.

## Routing lexicon

The supplied SDI implementation uses `config/routing_lexicon.yaml`. Its matcher includes concepts such as:

- Longest-phrase matching.
- Exclusive domain entries.
- Ambiguity flags.
- `unless` guards / exception conditions.

Unmatched phrases should not be forcibly assigned to a domain. Domain-specific follow-up memory is a separate requirement and should not be assumed to exist just because the lexicon exists.

## Prompt supplements

The supplied analysis identifies two prompt supplements:

- `route_supplement`: a compact set of routing instructions/context.
- `plan_supplement`: planning context such as catalog, executions, bounded conversation, workflow and user details.

Recheck which LLM calls receive which supplement. Do not assume all route, detail and planning calls receive identical context.

## Conversation limits reported in the persistence assessment

The later SDI source analysis reports:

- Maximum prior history: 6 messages.
- Maximum history characters: 4,000.
- Oldest messages are dropped first when limits are exceeded.
- No conversation summarization was found in the inspected code.
- The current question was excluded from duplicate history entries.

The UI request body was reported to contain the current message and session identifiers, rather than sending the full browser transcript to the runtime.

## Key design lesson

A Context Package is temporary, request-scoped preparation. It should be rebuilt on each turn from available state and relevant history. It is not automatically a persisted memory store.

For future changes, keep these concerns separate:

1. Conversation transcript persistence.
2. LangGraph checkpoint persistence.
3. Context selection and prompt construction.
4. LLM context-window limits.

## Recommended validation

- Confirm the builder runs once per user turn.
- Confirm the required routing and planning calls receive the intended supplements.
- Confirm the user identity cannot be overridden by model output.
- Confirm the history source is explicit and bounded.
- Confirm stale filters do not override explicit new filters.
