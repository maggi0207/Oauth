# Project Brain – Knowledge Ingestion Guide

## Recommended import boundaries

- Import `SDI/` into the SDI project knowledge space only.
- Import `LTB/` into the LTB project knowledge space only.
- Import `Global/` into the shared Global Office Knowledge space.

## Indexing guidance

- Treat Markdown headings as chunk boundaries.
- Preserve table headers with their rows when chunking.
- Preserve code fences as a unit where possible.
- Store the original relative path and heading for every chunk.
- Store an evidence/status label with each document.
- Do not merge SDI and LTB corpora into one unfiltered retrieval pool.
- For a project question, retrieve from the active project's knowledge space first; use Global only when relevant.

## Update process

When source code or official project documentation changes:

1. Review the document against the current repository.
2. Update the relevant Markdown file.
3. Update the `Last verified` date and evidence label.
4. Re-index the changed document.
5. Remove superseded guidance rather than leaving conflicting copies active.

## Sensitive content

Never import `.env` values, tokens, passwords, certificates, private keys, production connection strings or restricted business data into this starter knowledge pack.
