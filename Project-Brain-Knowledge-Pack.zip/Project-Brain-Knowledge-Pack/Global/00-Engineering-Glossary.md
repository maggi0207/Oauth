# Engineering Glossary – Project Brain

| Term | Meaning |
|---|---|
| Agent | AI-driven component that interprets a task and coordinates tools or workflows |
| Context Builder | Builds a request-specific package of relevant project, workflow and conversation information |
| Context Package | Temporary structured context assembled for a turn; not automatically a persistence store |
| Context Window | Amount of input/output context a model can process in a request |
| Thread ID | Stable identifier for a conversation/thread |
| Checkpointer | LangGraph persistence mechanism that saves/restores graph state by thread |
| PostgreSQL | Relational database that may store durable checkpoints when configured |
| MCP | Model Context Protocol; a standard interface for exposing tools/resources to models |
| Lexicon | Configured business vocabulary used to match terms and routing signals |
| RAG | Retrieval-Augmented Generation; retrieve relevant knowledge and provide it to an AI model |
| FTS5 | SQLite full-text search extension |
| Embedding | Numeric representation of content used for semantic similarity search |
| Runbook | Approved step-by-step operational procedure |
| Feature flag | Configuration that enables or disables a capability |
| Allowlist | Explicit set of capabilities/tools permitted to execute |
| SSE | Server-Sent Events; streaming data from backend to frontend |

## Important distinctions

- Thread ID identifies a conversation; it does not itself save memory.
- Checkpointer persists graph state; Context Builder selects context for the current request.
- Browser transcript and agent workflow memory are separate concerns.
- A feature flag is not by itself a hard security boundary; tool registration and execution must also be protected.
